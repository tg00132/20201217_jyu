class OperatePromotion {
    public static void main(String[] args) {
        short num1 = 11;
        short num2 = 22;
        short result = num1 + num2;
        System.out.println(result);
    }
}
