class TwoPlusFive
{
    public static void main(String[] args)
    {
        System.out.println("2 + 5 = " + 2 + 5 );
        System.out.println("2 + 5 = " + (2 + 5));
    }
}
